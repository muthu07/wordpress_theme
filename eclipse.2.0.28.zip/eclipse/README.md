Eclipse responsive Wordpress theme
====================================

- Eclipse
- by CyberChimps http://cyberchimps.com
- Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

- Bootstrap
- Adds core styles and responsive structure
- by Twitter Bootstrap http://getbootstrap.com/2.3.2/
- licensed under APLv2 - https://github.com/twitter/bootstrap/blob/master/LICENSE

- HTML5shiv
- adds HTML5 elements to browsers that are not HTML5 enabled
- https://code.google.com/p/html5shiv/
- Dual Licensed under MIT/GPL2 - http://opensource.org/licenses/mit-license.php / GNU General & Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

- jCarousel
- adds the responsive Carousel
- by Sorgalla http://sorgalla.com/jcarousel/
- dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.

- Slimbox
- adds the lightbox we use in Portfolio etc
- by Digitalia http://www.digitalia.be/software/slimbox
- licensed under the MIT license - http://www.opensource.org/licenses/mit-license.php

- jQuery UI Touch Punch
- adds touch grag and drop and swipe functionality
- by David Furfero http://touchpunch.furf.com/
- dual licensed under the MIT or GPL Version 2 licenses.

- Noto Sans and Imprima
- Fonts using @import from Google
- by Google http://www.google.com/fonts
- licensed under the Creative Commons license (http://creativecommons.org/licenses/by/3.0/) Google.com

- Magazine Image
- the magazine image used by default in the header image
- by 123rf http://123rf.com
- licensed under the 123RF LIMITED ROYALTY FREE LICENSE AGREEMENT (Extended Electronic Distribution RF License) http://www.123rf.com/license.php?type=el_electronic

- All other images
- by CyberChimps http://cyberchimps.com
- Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

====================================================================================================================================

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/

For updated docs please visit http://cyberchimps.com/guides/

For the support forum please visit: http://cyberchimps.com/forum/