        <div id="sidebar">
        
            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>       
                <div class="side_box">
                    <h3>Text widget</h3>
                    Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..
                </div><!--//side_box-->
                
                <div class="side_box">
                    <h3>Sample List</h3>
                    <ul>
                      <li><a href="#">Design</a></li>
                      <li><a href="#">Wordpress</a></li>
                      <li><a href="#">Blogspot</a></li>
                      <li><a href="#">Programming</a></li>
                    </ul>
                </div><!--//side_box-->            
                
                <div class="side_box">
                    <h3>Text widget</h3>
                    Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..
                </div><!--//side_box-->                            
            <?php endif; ?>     
            
        </div><!--//sidebar-->