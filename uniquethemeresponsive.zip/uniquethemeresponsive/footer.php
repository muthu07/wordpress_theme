    <div class="clear"></div>
    
    </div><!--//content-->
    
    <div id="footer">
    
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer') ) : ?>       
        
            <div class="footer_box">
                <h3>Footer Widget</h3>
                <p>Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..

</p>
            </div><!--//footer_box-->
            
            <div class="footer_box">
                <h3>Footer Widget</h3>
                <p>Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..</p>
            </div><!--//footer_box-->
    
            <div class="footer_box">
                <h3>Footer Widget</h3>
                <p>Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here.. </p>
            </div><!--//footer_box-->
            
        <?php endif; ?>                
        
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Last') ) : ?>       
        
            <div class="footer_box footer_box_last">
                <h3>Footer Widget</h3>
                <p>Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..Use widgets to insert text here..</p>
            </div><!--//footer_box-->        
        
        <?php endif; ?>                
        
        <div class="clear"></div>
    </div><!--//footer-->
    
    <div class="footer_copyright">© 2012 Unique Theme Responsive. Design and Developed by <a href="http://www.dessign.net">Dessign.net</a> Inspired by <a href="http://www.el-studio.co.uk/"> el-studio.co.uk</a></div>

</div><!--//main_container-->

<?php wp_footer(); ?>
</body>
</html>