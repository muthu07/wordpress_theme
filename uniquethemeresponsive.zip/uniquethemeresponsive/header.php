<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
<head> 
  <title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>          
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" title="no title" charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!--[if lt IE 9]>
	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->        
  <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript" charset="utf-8"></script>-->
  <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery-1.6.1.min.js"></script>
  <?php wp_head(); ?>
  
  <script type="text/javascript">
    var intervalID;
    
    function slideSwitch() {
        var $active = $('#slideshow a.active');
    
        if ( $active.length == 0 ) $active = $('#slideshow a:last');
    
        var $next =  $active.next().length ? $active.next()
            : $('#slideshow a:first');
    
        $active.addClass('last-active');
    
        $next.css({opacity: 0.0})
            .addClass('active')
            .animate({opacity: 1.0}, 1000, function() {
                $active.removeClass('active last-active');
            });
        clearInterval(intervalID);
        intervalID = setInterval( "slideSwitch()", 5000 );

    }
    
    function slideSwitch_prev() {
        var $active = $('#slideshow a.active');
    
        if ( $active.length == 0 ) $active = $('#slideshow a:first');
    
        var $next =  $active.prev().length ? $active.prev() : $('#slideshow a:last');
    
        $active.addClass('last-active');
    
        $next.css({opacity: 0.0})
            .addClass('active')
            .animate({opacity: 1.0}, 1000, function() {
                $active.removeClass('active last-active');
            });
        clearInterval(intervalID);
        intervalID = setInterval( "slideSwitch()", 5000 );

    }    
    
    $(function() {
        intervalID = setInterval( "slideSwitch()", 5000 );
    });    
  </script>        
</head>
<body>

<?php $shortname = "unique"; ?>

<div id="main_container">

    <div class="header_top">
    
        <div class="header_search_cont">
            <form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
            <input type="text" name="s" id="s" />
            <INPUT TYPE="image" src="<?php bloginfo('stylesheet_directory'); ?>/images/search-icon.png" class="search_icon" BORDER="0" ALT="Submit Form">
            </form>
        </div><!--//header_search_cont-->
        
        <ul class="social_list">
            <?php if(get_option($shortname.'_twitter_link','') != "") { ?>
              <li><a href="<?php echo get_option($shortname.'_twitter_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/twitter-icon.png" /></a></li>
            <?php } ?>
            <?php if(get_option($shortname.'_facebook_link','') != "") { ?>
              <li><a href="<?php echo get_option($shortname.'_facebook_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/facebook-icon.png" /></a></li>
            <?php } ?>
            <?php if(get_option($shortname.'_google_plus_link','') != "") { ?>
              <li><a href="<?php echo get_option($shortname.'_google_plus_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/gplus-icon.png" /></a></li>
            <?php } ?>
            <?php if(get_option($shortname.'_dribbble_link','') != "") { ?>
              <li><a href="<?php echo get_option($shortname.'_dribbble_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/dribbble-icon.png" /></a></li>
            <?php } ?>
            <?php if(get_option($shortname.'_pinterest_link','') != "") { ?>
              <li><a href="<?php echo get_option($shortname.'_pinterest_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/pinterest-icon.png" /></a></li>
            <?php } ?>        
        </ul>
        <div class="clear"></div>
    
    </div><!--//header_top-->
    
    <div id="menu_container">
    
    <!--
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">Contact</a></li>
        </ul>-->
        <?php wp_nav_menu('menu=header_menu&container=false'); ?>
        
        <!--
        <ul class="cat_list">
          <li><a href="#">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">Contact</a></li>
        </ul>        -->
        <?php wp_nav_menu('menu=category_menu&container=false&menu_class=cat_list'); ?>
        <div class="clear"></div>
    
    </div><!--//menu_container-->
    
    <div class="logo_cont">
        <div align="center">
            <?php if(get_option($shortname.'_custom_logo_url','') != "") { ?>
              <a href="<?php bloginfo('url'); ?>"><img src="<?php echo stripslashes(stripslashes(get_option($shortname.'_custom_logo_url',''))); ?>" class="logo" /></a>
            <?php } else { ?>
              <a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo.png" class="logo" /></a>
            <?php } ?>                            
        </div>
    </div><!--//logo_cont-->
    
    <div id="content">